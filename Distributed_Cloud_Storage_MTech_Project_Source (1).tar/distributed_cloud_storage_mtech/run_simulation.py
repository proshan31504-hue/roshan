import os
import sys
import json
import base64
import hashlib
from hashlib import sha256
from storage_ring import ConsistentHashRing

try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
    import zfec
except ImportError:
    print("[!] Run: pip install pycryptodome zfec")

class DistributedStorageClient:
    def __init__(self, nodes, K=4, M=2):
        self.K = K  # Data shards
        self.M = M  # Parity shards
        self.N = K + M
        self.nodes = nodes
        self.ring = ConsistentHashRing(replicas=50)
        for n in nodes:
            self.ring.add_node(n)
        self.secret_key = get_random_bytes(32) # AES-256 Key

    def encrypt_payload(self, data: bytes) -> bytes:
        cipher = AES.new(self.secret_key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        return cipher.nonce + tag + ciphertext

    def decrypt_payload(self, encrypted_data: bytes) -> bytes:
        nonce = encrypted_data[:16]
        tag = encrypted_data[16:32]
        ciphertext = encrypted_data[32:]
        cipher = AES.new(self.secret_key, AES.MODE_GCM, nonce=nonce)
        return cipher.decrypt_and_verify(ciphertext, tag)

    def encode_erasure(self, data: bytes):
        encoder = zfec.Encoder(self.K, self.N)
        # Pad data if not divisible by K
        pad_len = (self.K - (len(data) % self.K)) % self.K
        padded_data = data + b'\x00' * pad_len
        shard_size = len(padded_data) // self.K
        
        input_blocks = [padded_data[i*shard_size:(i+1)*shard_size] for i in range(self.K)]
        shards = encoder.encode(input_blocks)
        return shards, pad_len

    def store_file(self, filename: str, content: bytes, storage_dir: str):
        print(f"\n--- [STEP 1] Encrypting File '{filename}' (AES-256-GCM) ---")
        encrypted = self.encrypt_payload(content)
        
        print(f"--- [STEP 2] Erasure Coding RS({self.K},{self.M}) -> Generating {self.N} Shards ---")
        shards, pad_len = self.encode_erasure(encrypted)
        
        manifest = {"filename": filename, "pad_len": pad_len, "shards": []}
        
        for idx, shard in enumerate(shards):
            shard_id = f"{filename}_shard_{idx}"
            target_node = self.ring.get_node(shard_id)
            node_dir = os.path.join(storage_dir, target_node)
            os.makedirs(node_dir, exist_ok=True)
            
            shard_path = os.path.join(node_dir, shard_id)
            with open(shard_path, "wb") as f:
                f.write(shard)
            
            manifest["shards"].append({"index": idx, "shard_id": shard_id, "node": target_node})
            print(f"  -> Shard {idx} stored on [{target_node}]")
            
        return manifest

    def retrieve_file(self, manifest: dict, storage_dir: str, simulated_dead_nodes=None) -> bytes:
        if simulated_dead_nodes is None:
            simulated_dead_nodes = []
            
        print(f"\n--- [STEP 3] Retrieving File Shards (Simulated Dead Nodes: {simulated_dead_nodes}) ---")
        retrieved_shards = []
        retrieved_indices = []
        
        for s_info in manifest["shards"]:
            idx = s_info["index"]
            target_node = s_info["node"]
            
            if target_node in simulated_dead_nodes:
                print(f"  [X] Node [{target_node}] is CRASHED/DOWN! Shard {idx} unavailable.")
                continue
                
            shard_path = os.path.join(storage_dir, target_node, s_info["shard_id"])
            if os.path.exists(shard_path):
                with open(shard_path, "rb") as f:
                    retrieved_shards.append(f.read())
                    retrieved_indices.append(idx)
                    print(f"  [✓] Retrieved Shard {idx} from [{target_node}]")
            
            if len(retrieved_shards) == self.K:
                print(f"  [!] Minimum required K={self.K} shards obtained. Halting fetch.")
                break
                
        if len(retrieved_shards) < self.K:
            raise RuntimeError(f"Data Loss Unrecoverable: Only {len(retrieved_shards)} shards available, need {self.K}")
            
        print(f"--- [STEP 4] Reconstructing Original File using Reed-Solomon Decoder ---")
        decoder = zfec.Decoder(self.K, self.N)
        reconstructed_blocks = decoder.decode(retrieved_shards, retrieved_indices)
        reconstructed_encrypted = b"".join(reconstructed_blocks)
        
        if manifest["pad_len"] > 0:
            reconstructed_encrypted = reconstructed_encrypted[:-manifest["pad_len"]]
            
        print(f"--- [STEP 5] Decrypting Payload (AES-256-GCM) ---")
        decrypted = self.decrypt_payload(reconstructed_encrypted)
        return decrypted

if __name__ == "__main__":
    base_dir = "./mtech_storage_testbed"
    nodes = [f"Node_{i}" for i in range(1, 7)] # 6 Storage Nodes
    
    client = DistributedStorageClient(nodes=nodes, K=4, M=2)
    
    sample_text = b"Distributed Cloud Storage System - M.Tech Research Project Source Code Simulation.\n" * 20
    filename = "mtech_dissertation_data.txt"
    
    # Store
    manifest = client.store_file(filename, sample_text, base_dir)
    
    # Simulate Failure of 2 Nodes
    dead_nodes = ["Node_1", "Node_3"]
    retrieved_data = client.retrieve_file(manifest, base_dir, simulated_dead_nodes=dead_nodes)
    
    print("\n=== INTEGRITY VERIFICATION ===")
    if retrieved_data == sample_text:
        print(" SUCCESS: Original file reconstructed perfectly despite 2 nodes crashing!")
    else:
        print(" FAILED: Data corruption detected.")
