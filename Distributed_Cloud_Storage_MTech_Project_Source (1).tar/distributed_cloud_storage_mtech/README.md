# Distributed Cloud Storage System (M.Tech Project)

An M.Tech level fault-tolerant, scalable, and secure Distributed Cloud Storage System built using **Python**, **Erasure Coding (Reed-Solomon)**, **Consistent Hashing**, and **AES-256 Client-Side Encryption**.

## Architecture Overview
1. **Client Layer:**
   - Client-side AES-256-GCM Encryption (Zero-Knowledge Architecture).
   - Erasure Coding using Reed-Solomon (K=4 Data Shards, M=2 Parity Shards).
2. **Metadata & Overlay Ring:**
   - SHA-256 Consistent Hashing Ring with Virtual Nodes.
   - Fault Tolerance: Can recover full original file even if any 2 nodes crash.
3. **Storage Nodes:**
   - Multi-node simulation using Python HTTP/gRPC API microservices.

## Project Structure
```
distributed_cloud_storage_mtech/
├── client/
│   └── client.py          # Encrypts, splits, uploads & downloads files
├── storage_ring.py        # Consistent Hashing implementation
├── storage_node.py        # Independent node server process
├── run_simulation.py      # Master simulation orchestrator (starts nodes, uploads, simulates node crash & recovers data)
├── requirements.txt       # Dependencies
└── README.md
```

## Quick Start Guide
```bash
pip install -r requirements.txt
python run_simulation.py
```
